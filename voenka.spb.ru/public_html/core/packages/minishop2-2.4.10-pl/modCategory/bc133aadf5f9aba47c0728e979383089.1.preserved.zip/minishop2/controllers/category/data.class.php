<?php
class msCategoryDataManagerController extends ResourceDataManagerController {}
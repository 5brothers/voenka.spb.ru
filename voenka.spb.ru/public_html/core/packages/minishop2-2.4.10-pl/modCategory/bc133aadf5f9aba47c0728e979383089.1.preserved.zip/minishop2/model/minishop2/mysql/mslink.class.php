<?php
require_once (dirname(dirname(__FILE__)) . '/mslink.class.php');
class msLink_mysql extends msLink {}
<?php
require_once (dirname(dirname(__FILE__)) . '/msproductfile.class.php');
class msProductFile_mysql extends msProductFile {}
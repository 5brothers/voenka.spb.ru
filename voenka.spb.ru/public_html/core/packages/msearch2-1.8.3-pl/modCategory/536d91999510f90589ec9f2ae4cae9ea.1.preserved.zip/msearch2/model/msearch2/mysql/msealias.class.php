<?php
require_once (dirname(dirname(__FILE__)) . '/msealias.class.php');
class mseAlias_mysql extends mseAlias {}
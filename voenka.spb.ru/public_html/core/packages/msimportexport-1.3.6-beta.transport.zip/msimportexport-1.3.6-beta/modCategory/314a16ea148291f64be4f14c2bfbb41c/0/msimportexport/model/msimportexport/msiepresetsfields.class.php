<?php
class MsiePresetsFields extends xPDOSimpleObject {}
<?php
$xpdo_meta_map['MsieHeadAlias']= array (
  'package' => 'msimportexport',
  'version' => '1.1',
  'table' => 'msie_head_alias',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'key' => NULL,
    'value' => NULL,
  ),
  'fieldMeta' => 
  array (
    'key' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => false,
    ),
    'value' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => false,
    ),
  ),
);

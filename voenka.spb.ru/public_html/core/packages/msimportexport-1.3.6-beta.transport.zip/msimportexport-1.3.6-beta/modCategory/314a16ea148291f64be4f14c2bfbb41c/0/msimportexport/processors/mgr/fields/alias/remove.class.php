<?php
class msImportExportRemoveProcessor extends modObjectRemoveProcessor {
    public $languageTopics = array('msimportexport:default');
    public $classKey = 'MsieHeadAlias';
}
return 'msImportExportRemoveProcessor';
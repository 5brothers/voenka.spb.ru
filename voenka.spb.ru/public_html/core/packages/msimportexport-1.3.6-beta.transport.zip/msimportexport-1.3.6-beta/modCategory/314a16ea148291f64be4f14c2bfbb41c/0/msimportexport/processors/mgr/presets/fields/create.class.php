<?php
class  msImportExportCreateProcessor extends modObjectCreateProcessor {
    public $classKey = 'MsiePresetsFields';
    public $languageTopics = array('msimportexport:default');
}
return 'msImportExportCreateProcessor';
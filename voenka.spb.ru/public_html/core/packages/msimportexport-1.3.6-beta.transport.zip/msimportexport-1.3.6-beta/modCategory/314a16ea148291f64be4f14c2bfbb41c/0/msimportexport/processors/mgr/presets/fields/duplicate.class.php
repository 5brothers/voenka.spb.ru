<?php

class msImportExportDuplicateProcessor extends modObjectDuplicateProcessor {
	public $languageTopics = array('msimportexport:default');
	public $classKey = 'MsiePresetsFields';
}
return 'msImportExportDuplicateProcessor';
<?php
/**
 * Properties Russian Lexicon Entries for mSklad
 *
 * @package msklad
 * @subpackage lexicon
 */
$_lang['msklad_prop_limit'] = 'Ограничение вывода Предметов на странице.';
$_lang['msklad_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['msklad_prop_sortBy'] = 'Поле сортировки.';
$_lang['msklad_prop_sortDir'] = 'Направление сортировки.';
$_lang['msklad_prop_tpl'] = 'Чанк оформления каждого ряда Предметов.';
$_lang['msklad_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
$_lang['msklad_prop_source_err_ae'] = 'Привязка с данным источником уже существует';
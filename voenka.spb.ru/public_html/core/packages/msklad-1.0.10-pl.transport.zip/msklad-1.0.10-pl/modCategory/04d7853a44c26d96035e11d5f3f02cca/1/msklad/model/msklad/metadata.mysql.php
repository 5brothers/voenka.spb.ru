<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'mSkladCategoryData',
    1 => 'mSkladProductData',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'mSkladCategoryExchange',
    1 => 'mSkladCategoryTemp',
    2 => 'mSkladProductExchange',
    3 => 'mSkladProductTemp',
    4 => 'mSkladProductProperty',
  ),
);
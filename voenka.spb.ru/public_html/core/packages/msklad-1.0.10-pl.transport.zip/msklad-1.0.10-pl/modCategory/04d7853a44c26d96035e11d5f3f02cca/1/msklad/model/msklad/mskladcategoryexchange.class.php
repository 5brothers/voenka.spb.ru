<?php
class mSkladCategoryExchange extends xPDOSimpleObject {}
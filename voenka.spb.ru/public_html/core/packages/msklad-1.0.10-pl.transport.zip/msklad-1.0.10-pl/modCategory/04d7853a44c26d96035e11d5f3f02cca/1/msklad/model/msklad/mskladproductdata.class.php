<?php
class mSkladProductData extends xPDOObject {}
<?php
class mSkladProductExchange extends xPDOSimpleObject {}
<?php
class mSkladProductProperty extends xPDOSimpleObject {}
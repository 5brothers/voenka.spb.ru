<?php
require_once (dirname(dirname(__FILE__)) . '/mskladcategorydata.class.php');
class mSkladCategoryData_mysql extends mSkladCategoryData {}
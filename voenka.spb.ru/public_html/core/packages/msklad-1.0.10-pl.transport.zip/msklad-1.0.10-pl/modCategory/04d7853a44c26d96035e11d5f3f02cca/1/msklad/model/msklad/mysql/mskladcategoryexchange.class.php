<?php
require_once (dirname(dirname(__FILE__)) . '/mskladcategoryexchange.class.php');
class mSkladCategoryExchange_mysql extends mSkladCategoryExchange {}
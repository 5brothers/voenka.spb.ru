<?php
require_once (dirname(dirname(__FILE__)) . '/mskladcategorytemp.class.php');
class mSkladCategoryTemp_mysql extends mSkladCategoryTemp {}
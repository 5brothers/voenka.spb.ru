<?php
require_once (dirname(dirname(__FILE__)) . '/mskladproductdata.class.php');
class mSkladProductData_mysql extends mSkladProductData {}